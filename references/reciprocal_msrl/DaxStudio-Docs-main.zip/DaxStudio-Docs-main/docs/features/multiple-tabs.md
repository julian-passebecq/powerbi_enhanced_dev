---
title: Multiple Tabs
---

DAX Studio supports multiple tabs, the user interface is multi-threaded so you can have a query running in one window while you work on a different query in another window.

![](multiple-tabs.png)

You can open a new tab using the File -> New menu (or with the Ctrl+N hotkey)

Or you can use Ctrl+Shift+N to open a new tab with the same connection as the current active tab