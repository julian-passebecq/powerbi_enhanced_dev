@ECHO OFF
pushd "%~dp0"
ECHO.
ECHO.
ECHO.
ECHO This script deletes all temporary build files in their
ECHO corresponding BIN and OBJ Folder contained in the following projects
ECHO.
ECHO DaxStudio.Standalone
ECHO DaxStudio.ExcelAddin
ECHO DaxStudio.Checker
ECHO.
ECHO ADOTabular
ECHO DaxEditor
ECHO DaxStudio.UI
ECHO DaxStudio.Interfaces
ECHO DaxStudio.Common
ECHO DaxStudio.QueryTrace
ECHO DaxStudio.QueryTrace.Excel
ECHO UnitComboLib
ECHO.
ECHO.
REM Ask the user if hes really sure to continue beyond this point XXXXXXXX
set /p choice=Are you sure you want to continue (Y/N)?
if '%choice%' == 'Y' Goto Next
else if '%choice%' == 'y' Goto Next
else Goto EndOfBatch
:Next
REM Script does not continue unless user types 'Y' in upper case letter
ECHO.
ECHO XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
ECHO.
ECHO XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
ECHO.
ECHO Removing vs settings folder with *.sou file
ECHO.
RMDIR /S /Q .vs

ECHO Deleting BIN and OBJ Folders in src\ADOTabular
ECHO.
RMDIR /S /Q src\ADOTabular\bin
RMDIR /S /Q src\ADOTabular\obj

ECHO Deleting BIN and OBJ Folders in src\AvalonDock.Themes.DaxStudio
ECHO.
RMDIR /S /Q src\AvalonDock.Themes.DaxStudio\bin
RMDIR /S /Q src\AvalonDock.Themes.DaxStudio\obj

ECHO Deleting BIN and OBJ Folders in DaxEditor
ECHO.
RMDIR /S /Q src\DaxEditor\bin
RMDIR /S /Q src\DaxEditor\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Checker
ECHO.
RMDIR /S /Q src\DaxStudio.Checker\bin
RMDIR /S /Q src\DaxStudio.Checker\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Common
ECHO.
RMDIR /S /Q src\DaxStudio.Common\bin
RMDIR /S /Q src\DaxStudio.Common\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.CommandLine
ECHO.
RMDIR /S /Q src\DaxStudio.CommandLine\bin
RMDIR /S /Q src\DaxStudio.CommandLine\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Controls.DataGridFilter
ECHO.
RMDIR /S /Q src\DaxStudio.Controls.DataGridFilter\bin
RMDIR /S /Q src\DaxStudio.Controls.DataGridFilter\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Controls.DataGridFilter
ECHO.
RMDIR /S /Q src\DaxStudio.Controls.PropertyGrid\bin
RMDIR /S /Q src\DaxStudio.Controls.PropertyGrid\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.ExcelAddin
ECHO.
RMDIR /S /Q src\DaxStudio.ExcelAddin\bin
RMDIR /S /Q src\DaxStudio.ExcelAddin\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.FileIcons
ECHO.
RMDIR /S /Q src\DaxStudio.FileIcons\bin
RMDIR /S /Q src\DaxStudio.FileIcons\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Interfaces
ECHO.
RMDIR /S /Q src\DaxStudio.Interfaces\bin
RMDIR /S /Q src\DaxStudio.Interfaces\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Launcher
ECHO.
RMDIR /S /Q src\DaxStudio.UriHandler\bin
RMDIR /S /Q src\DaxStudio.Interfaces\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.QueryTrace
ECHO.
RMDIR /S /Q src\DaxStudio.QueryTrace\bin
RMDIR /S /Q src\DaxStudio.QueryTrace\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.QueryTrace.Excel

ECHO.
RMDIR /S /Q src\DaxStudio.QueryTrace.Excel\bin
RMDIR /S /Q src\DaxStudio.QueryTrace.Excel\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.SqlFormatter
ECHO.
RMDIR /S /Q src\DaxStudio.SqlFormatter\bin
RMDIR /S /Q src\DaxStudio.SqlFormatter\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Standalone
ECHO.
RMDIR /S /Q src\DaxStudio.Standalone\bin
RMDIR /S /Q src\DaxStudio.Standalone\obj
RMDIR /S /Q src\bin
RMDIR /S /Q src\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.UI
ECHO.
RMDIR /S /Q src\DaxStudio.UI\bin
RMDIR /S /Q src\DaxStudio.UI\obj

ECHO Deleting BIN and OBJ Folders in UnitComboLib
ECHO.
RMDIR /S /Q src\UnitComboLib\bin
RMDIR /S /Q src\UnitComboLib\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.Tests
ECHO.
RMDIR /S /Q tests\DaxStudio.Tests\bin
RMDIR /S /Q tests\DaxStudio.Tests\obj

ECHO Deleting BIN and OBJ Folders in DaxStudio.CommandLineTests
ECHO.
RMDIR /S /Q tests\DaxStudio.CommandLineTests\bin
RMDIR /S /Q tests\DaxStudio.CommandLineTests\obj

PAUSE

:EndOfBatch
