﻿using ADOTabular.AdomdClientWrappers;
using ADOTabular.Enums;
using ADOTabular.Extensions;
using ADOTabular.Interfaces;
using ADOTabular.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace ADOTabular
{
    public class ADOTabularConnection : IDisposable, IADOTabularConnection
    {
        private AdomdCommand _runningCommand;

        public event EventHandler ConnectionChanged;
        private AdomdConnection _adomdConn;
        private string _currentDatabase;
        private readonly Regex _LocaleIdRegex = new Regex("Locale Identifier\\s*=\\s*(\\d+)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private readonly object connectionLock = new object();

        public ADOTabularConnection(string connectionString, AdomdType connectionType)
            : this(connectionString, connectionType, ADOTabularMetadataDiscovery.Csdl)
        { }

        public ADOTabularConnection(string connectionString, AdomdType connectionType, ADOTabularMetadataDiscovery visitorType)
            : this(connectionString, connectionType, true, visitorType)
        { }

        public ADOTabularConnection(string connectionString, AdomdType connectionType, bool showHidden)
            : this(connectionString, connectionType, showHidden, ADOTabularMetadataDiscovery.Csdl)
        { }

        public
#if NET8_0_OR_GREATER
            Microsoft.AnalysisServices.AccessToken
#else
            Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
            AccessToken
        {
            get => _adomdConn == null
                ? default(
#if NET8_0_OR_GREATER
                    Microsoft.AnalysisServices.AccessToken
#else
                    Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
                    )
                : _adomdConn.AccessToken;
            set
            {
                if (_adomdConn == null) return;
                // Centralized guard - the AdomdClient throws ArgumentException("The token has expired.")
                // if an expired token is assigned, so renew it before it ever reaches the client.
                _adomdConn.AccessToken = EnsureValidAccessToken(value);
            }
        }

        public Func<
#if NET8_0_OR_GREATER
            Microsoft.AnalysisServices.AccessToken, Microsoft.AnalysisServices.AccessToken
#else
            Microsoft.AnalysisServices.AdomdClient.AccessToken, Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
            > OnAccessTokenExpired
        {
            get => _adomdConn.OnAccessTokenExpired;
            set => _adomdConn.OnAccessTokenExpired = value;
        }

        /// <summary>
        /// The amount of time before the actual expiry at which a token is treated as expired. A token
        /// that is about to expire can lapse during the Open()/ChangeDatabase() round-trip that follows
        /// the assignment, so we renew slightly early rather than racing the clock.
        /// </summary>
        private static readonly TimeSpan AccessTokenExpiryBuffer = TimeSpan.FromMinutes(2);

        /// <summary>
        /// Returns a non-expired access token, renewing it via <see cref="OnAccessTokenExpired"/> when
        /// the supplied token has expired (or is about to). The AdomdClient rejects expired tokens when
        /// they are assigned, and it will not invoke the renewal callback for a connection that has no
        /// baseline token (which is common after a session has been idle for a long time - e.g.
        /// populating a tooltip or the background schema-change poller). Centralizing the check here
        /// means no caller can push an expired token onto a connection.
        /// Callers must assign <see cref="OnAccessTokenExpired"/> before assigning the token.
        /// </summary>
        private
#if NET8_0_OR_GREATER
            Microsoft.AnalysisServices.AccessToken
#else
            Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
            EnsureValidAccessToken(
#if NET8_0_OR_GREATER
            Microsoft.AnalysisServices.AccessToken
#else
            Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
            token)
        {
            // an unset/default token is a valid state - it means this connection does not use Entra auth
            if (token.Equals(default(
#if NET8_0_OR_GREATER
                Microsoft.AnalysisServices.AccessToken
#else
                Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
                ))) return token;

            if (token.ExpirationTime > DateTimeOffset.UtcNow.Add(AccessTokenExpiryBuffer)) return token;

            if (OnAccessTokenExpired == null)
                throw new InvalidOperationException(
                    $"The access token expired at {token.ExpirationTime:u} and no token renewal callback has been configured for this connection.");

            return OnAccessTokenExpired(token);
        }

        public ADOTabularConnection(string connectionString, AdomdType connectionType, bool showHiddenObjects, ADOTabularMetadataDiscovery visitorType)
        {

            ShowHiddenObjects = showHiddenObjects;
            ConnectionString = connectionString;
            if (!string.IsNullOrEmpty(connectionString))
                _adomdConn = new ADOTabular.AdomdClientWrappers.AdomdConnection(ConnectionString, connectionType);

            Type = connectionType;
            //   _adomdConn.ConnectionString = connectionString;

            //_adomdConn.Open();
            if (visitorType == ADOTabularMetadataDiscovery.Adomd)
            {
                Visitor = new MetaDataVisitorADOMD(this);
            }
            else
            {
                Visitor = new MetaDataVisitorCSDL(this);
            }
            ConnectionChanged?.Invoke(this, new EventArgs());
        }

        private ADOTabularDatabase _db;

        // returns the current database for the connection
        public ADOTabularDatabase Database
        {

            get
            {
                //_adomdConn.UnderlyingConnection.Databases

                try
                {
                    // if there is no connection this must be an "offline" connection
                    // like a vpax file.
                    if (_adomdConn == null)
                    {
                        lock (connectionLock)
                        {
                            var db2 = Visitor.Visit(this);
                            return db2;
                        }
                    }

                    if (_adomdConn.State != ConnectionState.Open)
                    {
                        this.Open();
                    }
                    var dd = Databases.GetDatabaseDictionary(this.SPID);

                    if (string.IsNullOrWhiteSpace(_currentDatabase) && _adomdConn.State == ConnectionState.Open) _currentDatabase = _adomdConn.Database;

                    if (!dd.ContainsKey(_currentDatabase))
                    {
                        dd = Databases.GetDatabaseDictionary(this.SPID, true);
                    }
                    //var db = dd[_adomdConn.Database];
                    if (string.IsNullOrEmpty(_currentDatabase) && dd.Count == 0)
                    {
                        // return an empty database object if there is no current database or no databases on the server
                        return new ADOTabularDatabase(this, "", "", DateTime.MinValue, "", "", "");
                    }
                    // The Power BI XMLA endpoint does not set a default database, so we have a collection of database, but no current database
                    // in this case we just set the current database to the first in the list
                    if (string.IsNullOrEmpty(_currentDatabase) && dd.Count > 0)
                    {
                        var details = dd.First().Value;
                        _db = new ADOTabularDatabase(this, details.Name, details.Id, details.LastUpdate, details.CompatibilityLevel, details.Roles, details.Description);
                        ChangeDatabase(details.Name);

                    }

                    // todo - somehow users are getting here, but the current database is not in the dictionary
                    var db = dd[_currentDatabase];
                    if (_db == null || db.Id != _db.Id) // && db.Name != FileName)
                    {
                        _db = new ADOTabularDatabase(this, db.Name, db.Id, db.LastUpdate, db.CompatibilityLevel, db.Roles, db.Description);
                        _db.Caption = db.Caption;
                    }

                    return _db;
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error in Database property: {ex.Message}");
                    throw;
                    //return null;
                }
            }
        }

        public async Task OpenAsync()
        {
            await Task.Run(() => Open()).ConfigureAwait(true);
        }

        public void Open()
        {
            if (_adomdConn.State == ConnectionState.Open)
            {
                return;
            }
            _adomdConn.Open();
            CacheDatabases();
            ChangeDatabase(_adomdConn.Database);
            CacheKeywords();
            CacheFunctionGroups();
            try
            {
                UpdateServerProperties();
            }
            catch
            {
                Debug.WriteLine("Unable to update server properties");
            }
            // We do not cache DaxMetadata intentionally - it is saved manually, there is no need to read them every time
        }

        private void CacheDatabases()
        {
            this.Databases.GetDatabaseDictionary(this.SPID);
        }

        private void CacheFunctionGroups()
        {
            _functionGroups ??= new ADOTabularFunctionGroupCollection(this);
        }

        private void CacheKeywords()
        {
            _keywords ??= new ADOTabularKeywordCollection(this);
        }

        /*       public void Open(string connectionString)
               {
                   _adomdConn.Open(connectionString);
                   if (ConnectionChanged!=null)
                       ConnectionChanged(this,new EventArgs());
               }
               */

        public void ChangeDatabase(string database)
        {
            _currentDatabase = database;
            if (_adomdConn == null) return; // if we have opened a vpax file the connection object will be null
            if (_adomdConn.State != ConnectionState.Open)
            {
                _adomdConn.Open();
            }

            //if (_adomdConn.Database != database)
            //{
            _adomdConn.ChangeDatabase(database);
            //}

            if (string.IsNullOrEmpty(database) && this.Databases.Count > 0)
            {
                _currentDatabase = Databases[0];
                _adomdConn.ChangeDatabase(_currentDatabase);
            }

            _spid = 0; // reset the spid to 0 so that it will get re-evaluated
                       // the PowerBI xmla endpoint sets the permissions to call DISCOVER_SESSIONS on a per data set basis
                       // depending on whether the user has admin access to the given data set

            ConnectionChanged?.Invoke(this, new EventArgs());

        }

        private bool _showHiddenObjects;
        public bool ShowHiddenObjects
        {
            get => _showHiddenObjects;
            set
            {
                if (_adomdConn != null)
                {
                    if (_adomdConn.State == ConnectionState.Open)
                        throw new Exception("Cannot set the ShowHiddenObjects setting while the connection is open");
                }
                _showHiddenObjects = value;
            }
        }

        public ADOTabularConnectionType ConnectionType { get; private set; }


        public AdomdType Type
        {
            get;
            set;
        }


        public bool SupportsQueryTable => Type == AdomdType.AnalysisServices;

        public override string ToString()
        {
            return _adomdConn.ConnectionString;
        }

        private string _connectionString = "";

        public Dictionary<string, string> Properties { get; private set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public string ConnectionString
        {
            get
            {
                var connstr = _connectionString;
                if (string.IsNullOrEmpty(connstr)) return connstr;

                if (connstr.IndexOf("Show Hidden Cubes", StringComparison.OrdinalIgnoreCase) == -1 && ShowHiddenObjects)
                {
                    connstr =
                        string.Format(CultureInfo.InvariantCulture
                            , connstr.EndsWith(";", StringComparison.InvariantCulture)
                                ? "{0}Show Hidden Cubes=true"
                                : "{0};Show Hidden Cubes=true", connstr);
                }
                return connstr;
            }
            set
            {
                _connectionString = value;
                if (_connectionString != null)
                {
                    Properties = SplitConnectionString(_connectionString);
                    ConnectionType = GetConnectionType(ServerName);
                    IsTestingRls = HasRlsParameters(_connectionString);
                    //_connectionProps = ConnectionStringParser.Parse(_connectionString);
                }
            }
        }

        private static ADOTabularConnectionType GetConnectionType(string serverName)
        {
            var lowerServerName = serverName.Trim();
            if (lowerServerName.StartsWith("localhost", StringComparison.OrdinalIgnoreCase)) return ADOTabularConnectionType.LocalMachine;
            if (lowerServerName.StartsWith("asazure:", StringComparison.OrdinalIgnoreCase)
             || lowerServerName.StartsWith("powerbi:", StringComparison.OrdinalIgnoreCase)) return ADOTabularConnectionType.Cloud;
            return ADOTabularConnectionType.LocalNetwork;
        }

        private static Dictionary<string, string> SplitConnectionString(string connectionString)
        {
            var props = ConnectionStringParser.Parse(connectionString);

            return props;
        }


        // In ADO we set the current DB in the connection string
        // so having a collection of database objects may not be 
        // appropriate
        //
        // currently just returning a collection of available database names (not database objects)
        private ADOTabularDatabaseCollection _adoTabDatabaseColl;
        public ADOTabularDatabaseCollection Databases
        {
            get
            {
                if (_adoTabDatabaseColl == null)
                {
                    if (_adomdConn != null || Database != null)
                    {
                        lock (connectionLock)
                        {
                            _adoTabDatabaseColl = new ADOTabularDatabaseCollection(this);
                        }
                    }
                    else
                    {

                        throw new InvalidOperationException("Unable to populate Databases collection - a valid connection has not been established");
                    }
                }
                return _adoTabDatabaseColl;
            }
        }

        public int Count
        {
            get
            {
                return _adoTabDatabaseColl.Count;
            }
        }

        public DataSet GetSchemaDataSet(string dataSet)
        {
            if (_adomdConn?.State != ConnectionState.Open && _adomdConn != null) _adomdConn.Open();
            return _adomdConn?.GetSchemaDataSet(dataSet, null, true);
        }


        public DataSet GetSchemaDataSet(string dataSet, AdomdRestrictionCollection restrictions)
        {
            if (_adomdConn.State != ConnectionState.Open)
            {
                _adomdConn.Open();
            }
            return _adomdConn.GetSchemaDataSet(dataSet, restrictions, true);
        }

        public DataSet GetSchemaDataSet(string dataSet, AdomdRestrictionCollection restrictions, bool throwOnErrors)
        {
            if (_adomdConn.State != ConnectionState.Open)
            {
                _adomdConn.Open();
            }
            return _adomdConn.GetSchemaDataSet(dataSet, restrictions, throwOnErrors);

        }

        public void ExecuteNonQuery(string command)
        {
            var cmd = _adomdConn.CreateCommand();
            try
            {
                cmd.CommandText = command;
                cmd.CommandType = CommandType.Text;

                _ = cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }

        }

        public void CancelSPID(int spid)
        {
            var cmd = $"<Cancel xmlns='http://schemas.microsoft.com/analysisservices/2003/engine'><SPID>{spid}</SPID></Cancel>";
            ExecuteNonQuery(cmd);
        }

        public void CancelQuery()
        {
            const string cmd = "<Cancel xmlns='http://schemas.microsoft.com/analysisservices/2003/engine'/>";
            ExecuteNonQuery(cmd);
        }

        public void Ping()
        {
            const string cmd = "<Batch xmlns='http://schemas.microsoft.com/analysisservices/2003/engine'/>";
            ExecuteNonQuery(cmd);
        }

        public void PingTrace()
        {

            // Ping the server by sending a discover request for the current catalog name
            //var restrictionCollection = new AdomdRestrictionCollection();
            //var restriction = new AdomdRestriction("PropertyName", "Catalog");
            //restrictionCollection.Add(restriction);
            _ = GetSchemaDataSet("MDSCHEMA_CUBES");

            //ExecuteNonQuery(cmd);
        }


        public ConnectionState State
        {
            get
            {
                if (_adomdConn == null) return ConnectionState.Closed;
                return _adomdConn.State;
            }
        }

        public ADOTabular.AdomdClientWrappers.AdomdDataReader ExecuteReaderForPrepare(string command, List<Microsoft.AnalysisServices.AdomdClient.AdomdParameter> paramList)
        {
            return ExecuteReader(command, paramList, true);
        }

        public ADOTabular.AdomdClientWrappers.AdomdDataReader ExecuteReader(string command, List<Microsoft.AnalysisServices.AdomdClient.AdomdParameter> paramList)
        {
            return ExecuteReader(command, paramList, false);
        }

        private ADOTabular.AdomdClientWrappers.AdomdDataReader ExecuteReader(string command, List<Microsoft.AnalysisServices.AdomdClient.AdomdParameter> paramList,bool prepare)
        {
            if (_runningCommand != null)
            {
                _runningCommand.Dispose();
                _runningCommand = null;
            }

            _runningCommand = _adomdConn.CreateCommand();
            _runningCommand.CommandType = CommandType.Text;
            _runningCommand.CommandText = command;
            if (prepare)
            {
                _runningCommand.Properties.Add(new Microsoft.AnalysisServices.AdomdClient.AdomdProperty("ExecutionMode", "Prepare"));
            }

            if (paramList != null)
            {
                foreach (var p in paramList)
                {
                    _runningCommand.Parameters.Add(p);
                }
            }

            // TOOO - add parameters to connection

            if (_adomdConn.State != ConnectionState.Open) _adomdConn.Open();
            AdomdDataReader rdr = _runningCommand.ExecuteReader();
            rdr.Connection = this;
            rdr.CommandText = command;
            return rdr;

        }

        public DataTable ExecuteDaxQueryDataTable(string query)
        {
            _runningCommand = _adomdConn.CreateCommand();
            try
            {
                _runningCommand.CommandType = CommandType.Text;
                _runningCommand.CommandText = query;
                var dt = new DataTable("DAXResult");
                using (var da = new AdomdDataAdapter(_runningCommand))
                {
                    if (_adomdConn.State != ConnectionState.Open) _adomdConn.Open();
                    da.Fill(dt);
                }
                _runningCommand.Dispose();
                _runningCommand = null;
                return dt;
            }
            finally
            {
                _runningCommand = null;
            }
        }

        public int ExecuteCommand(string command)
        {
            AdomdCommand cmd = _adomdConn.CreateCommand();
            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = command;
                if (_adomdConn.State != ConnectionState.Open) _adomdConn.Open();
                return cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Dispose();
            }
        }


        public void Close(bool endSession)
        {
            if (_adomdConn.State != ConnectionState.Closed && _adomdConn.State != ConnectionState.Broken)
            {
                _adomdConn.Close(endSession);
                _spid = 0;
            }
        }

        public void Close()
        {
            if (_adomdConn.State != ConnectionState.Closed && _adomdConn.State != ConnectionState.Broken)
            {
                _adomdConn.Close();
                _spid = 0;
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _adomdConn?.Dispose();
                _runningCommand?.Dispose();
                _runningCommand = null;
                _spid = 0;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private ADOTabularFunctionGroupCollection _functionGroups;
        public ADOTabularFunctionGroupCollection FunctionGroups
        {
            get
            {
                CacheFunctionGroups();
                return _functionGroups;
            }
        }

        public IEnumerable<string> AllFunctions
        {
            get
            {
                foreach (var fg in FunctionGroups)
                {
                    foreach (var f in fg.Functions)
                    {
                        yield return f.Caption;
                    }
                }

            }
        }

        private MetadataInfo.DaxMetadata _daxMetadataInfo;
        public MetadataInfo.DaxMetadata DaxMetadataInfo
        {
            get
            {
                CacheDaxMetadataInfo();
                return _daxMetadataInfo;
            }
        }

        public void CacheDaxMetadataInfo()
        {
            if (_daxMetadataInfo == null) _daxMetadataInfo = new MetadataInfo.DaxMetadata(this);
        }

        private MetadataInfo.DaxColumnsRemap _daxColumnsRemapInfo;
        public MetadataInfo.DaxColumnsRemap DaxColumnsRemapInfo
        {
            get
            {
                CacheColumnRemapInfo();
                return _daxColumnsRemapInfo;
            }
        }

        public void CacheColumnRemapInfo()
        {
            if (_daxColumnsRemapInfo == null) _daxColumnsRemapInfo = new MetadataInfo.DaxColumnsRemap(this);
        }

        private MetadataInfo.DaxTablesRemap _daxTablesRemapInfo;
        public MetadataInfo.DaxTablesRemap DaxTablesRemapInfo
        {
            get
            {
                CacheTableRemapInfo();
                return _daxTablesRemapInfo;
            }
        }

        public void CacheTableRemapInfo()
        {
            if (_daxTablesRemapInfo == null) _daxTablesRemapInfo = new MetadataInfo.DaxTablesRemap(this);
        }

        private ADOTabularKeywordCollection _keywords;
        public ADOTabularKeywordCollection Keywords
        {
            get
            {
                CacheKeywords();
                return _keywords;
            }
        }

        private ADOTabularDynamicManagementViewCollection _dmvCollection;
        public ADOTabularDynamicManagementViewCollection DynamicManagementViews
        {
            get
            {
                if (_dmvCollection == null)
                {
                    _dmvCollection = new ADOTabularDynamicManagementViewCollection(this);
                }

                return _dmvCollection;
            }
        }

        public string ServerName
        {
            get
            {
                foreach (var prop in ConnectionString.Split(';'))
                {
                    if (prop.Trim().Length == 0) continue;
                    var p = prop.Split('=');
                    if (p[0] == "Data Source") return p[1].TrimStart('"').TrimEnd('"');
                }
                return "Not Connected";
            }
        }

        private string _svrVersion;
        public string ServerVersion
        {
            get
            {
                if (_svrVersion == null)
                {
                    _svrVersion = _adomdConn.ServerVersion;

                }
                return _svrVersion;
            }
            set => _svrVersion = value;
        }
        public string SessionId
        {
            get { return _adomdConn.SessionID; }
        }

        private string _serverMode;
        public string ServerMode
        {
            get
            {
                if (_serverMode == null)
                {
                    if (ServerType == ServerType.Offline)
                    {
                        _serverMode = "Offline";
                    }
                    else
                    {
                        _serverMode = GetServerMode();
                    }
                }
                return _serverMode;
            }
        }

        private string GetServerMode()
        {
            try
            {
                var ds = _adomdConn.GetSchemaDataSet("DISCOVER_XML_METADATA",
                                                     new AdomdRestrictionCollection
                                                         {
                                                         new AdomdRestriction("ObjectExpansion", "ReferenceOnly")
                                                         }, true);
                string metadata = ds.Tables[0].Rows[0]["METADATA"].ToString();

                using (XmlTextReader rdr = new XmlTextReader(new StringReader(metadata)) { DtdProcessing = DtdProcessing.Prohibit })
                {
                    if (rdr.NameTable != null)
                    {
                        var eSvrMode = rdr.NameTable.Add("ServerMode");

                        while (rdr.Read())
                        {
                            if (rdr.NodeType == XmlNodeType.Element
                                && rdr.LocalName == eSvrMode)
                            {
                                return rdr.ReadElementContentAsString();
                            }

                        }
                    }
                }
            }
            catch { }
            return "Unknown";
        }


        private string _serverId;
        public string ServerId
        {
            get
            {
                if (_serverId == null)
                {
                    _serverId = GetServerId();
                }
                return _serverId;
            }
        }

        private string GetServerId()
        {

            var ds = _adomdConn.GetSchemaDataSet("DISCOVER_XML_METADATA",
                                                 new AdomdRestrictionCollection
                                                     {
                                                         new AdomdRestriction("ObjectExpansion", "ReferenceOnly")
                                                     }, true);
            string metadata = ds.Tables[0].Rows[0]["METADATA"].ToString();

            using (XmlTextReader rdr = new XmlTextReader(new StringReader(metadata)) { DtdProcessing = DtdProcessing.Prohibit })
            {
                if (rdr.NameTable != null)
                {
                    var eSvrMode = rdr.NameTable.Add("ID");

                    while (rdr.Read())
                    {
                        if (rdr.NodeType == XmlNodeType.Element
                            && rdr.LocalName == eSvrMode)
                        {
                            return rdr.ReadElementContentAsString();
                        }

                    }
                }
            }
            return "Unknown";
        }

        private int _spid;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "<Pending>")]
        public int SPID
        {
            get
            {
                if (_spid == 0)
                {
                    try
                    {
                        //var resColl = new AdomdRestrictionCollection {{"SESSION_ID", SessionID}};
                        //var ds = GetSchemaDataSet("DISCOVER_SESSIONS", resColl);
                        var ds = GetSchemaDataSet("DISCOVER_SESSIONS");
                        if (ds == null)
                        {
                            _spid = -1;
                        }
                        else
                        {
                            foreach (var dr in ds.Tables[0].Rows.Cast<DataRow>().Where(dr => string.Equals(dr["SESSION_ID"].ToString(), SessionId, StringComparison.OrdinalIgnoreCase)))
                            {
                                _spid = int.Parse(dr["SESSION_SPID"].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }
                    catch (Exception)
                    {
                        _spid = -1;  // non-adminstrators cannot run DISCOVER_SESSIONS so we will return -1
                    }
                }
                return _spid;
            }
        }

        public IMetaDataVisitor Visitor { get; set; }

        public void Cancel()
        {

            if (_runningCommand == null)
            {
                return;
            }
            if (_runningCommand.Connection?.State != ConnectionState.Open) return;

            _runningCommand.Cancel();

        }

        /// <summary>
        /// TryCancel will attempt to cancel without throwing an exception if there is an error
        /// </summary>
        public void TryCancel()
        {
            try
            {
                Cancel();
            }
            catch (Exception)
            {
                // Swallow any errors
            }
        }


        public bool IsMultiDimensional => ServerMode == "Multidimensional";

        public bool IsPowerPivot { get; set; }
        public bool IsPowerBIorSSDT => ServerType == ServerType.PowerBIDesktop || ServerType == ServerType.SSDT;

        // BeginQueryAsync
        /*
        public void BeginQueryAsync(string query)
        {
            Task<TResult> t = new Task(ExecuteDaxQueryDataTableTask, query);
            t.Start();
        }

        public void ExecuteDaxQueryDataTableTask(string query)
        {
            ExecuteDaxQueryDataTable(query)
        }
        */
        // QueryComplete

        private string _powerBIFileName = string.Empty;
        private string _currentCube = string.Empty;

        public string FileName
        {
            get => _powerBIFileName;
            set
            {
                _powerBIFileName = value ?? throw new ArgumentNullException(nameof(FileName));
                if (string.IsNullOrEmpty(_powerBIFileName)) return;
                if (_powerBIFileName.StartsWith("https://", StringComparison.OrdinalIgnoreCase)
                  || _powerBIFileName.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
                {
                    ShortFileName = _powerBIFileName.Split('/').Last();
                }
                else
                {
#pragma warning disable CA1031 // Do not catch general exception types
                    try
                    {
                        ShortFileName = new FileInfo(_powerBIFileName).Name;
                    }
                    catch
                    {
                        // if there are any errors fallback to using the filename as the ShortName
                        ShortFileName = _powerBIFileName;
                    }
#pragma warning restore CA1031 // Do not catch general exception types
                }
            }
        }


        public void SetCube(string cubeName)
        {
            _currentCube = cubeName;
            _adomdConn.Close();
            _adomdConn = new ADOTabular.AdomdClientWrappers.AdomdConnection($"{ConnectionString};Cube={cubeName};Initial Catalog={Database.Name}", AdomdType.AnalysisServices);
        }

        public bool Is2012SP1OrLater
        {
            get
            {
                return Version.Parse(ServerVersion) >= new Version(11, 0, 3368, 0);
            }
        }

        public string ApplicationName
        {
            get
            {
                if (Properties == null) return "";
                if (!Properties.TryGetValue("Application Name", out string value)) return "";
                return value;
            }
        }

        public void Refresh()
        {
            Columns.Clear();
            _adoTabDatabaseColl = null;
            _db = null;
            _adomdConn.RefreshMetadata();
        }

        // This method forces in the Initial Catalog and Cube settings to the connection string 
        public string ConnectionStringWithInitialCatalog
        {
            get
            {
                var builder = new OleDbConnectionStringBuilder(ConnectionString)
                {
                    ["Initial Catalog"] = _currentDatabase
                };
                if (!string.IsNullOrEmpty(_currentCube)) builder["Cube"] = _currentCube;
                return builder.ToString();

                //return string.Format("{0};Initial Catalog={1}{2}", this.ConnectionString , _currentDatabase, CurrentCubeInternal);
            }
        }

        internal object CurrentCubeInternal => string.IsNullOrEmpty(_currentCube) ? string.Empty : $";Cube={_currentCube}";

        public Dictionary<string, ADOTabularColumn> Columns { get; } = new Dictionary<string, ADOTabularColumn>();

        public ServerType ServerType { get; set; }
        public string ServerLocation { get; private set; }
        public string ServerEdition { get; private set; }

        public int LocaleIdentifier
        {
            get
            {
                if (_adomdConn == null) return 0;
                if (_adomdConn.ConnectionString == null) return 0;
                if (_adomdConn.ConnectionString.Trim().Length == 0) return 0;
                var m = _LocaleIdRegex.Match(_adomdConn.ConnectionString);
                if (!m.Success) return 0;
                return int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
            }
        }

        public bool IsPowerBIXmla { get => this.Properties["Data Source"].IsPowerBIService(); }
        public string ShortFileName { get; private set; }

        public bool IsAdminConnection => SPID != -1 || IsTestingRls;

        public bool IsTestingRls { get; private set; } 

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "These properties are not critical so we just set them to empty strings on any exception")]
        private void UpdateServerProperties()
        {
            var res = new AdomdRestrictionCollection
            {
                new AdomdRestriction("ObjectExpansion", "ReferenceOnly")
            };
            var props = _adomdConn.GetSchemaDataSet("DISCOVER_XML_METADATA", res, true);
            var xmla = props.Tables[0].Rows[0][0].ToString();
            var xdoc = new XmlDocument() { XmlResolver = null };
            var oMgr = new XmlNamespaceManager(xdoc.NameTable);
            oMgr.AddNamespace("d", "http://schemas.microsoft.com/analysisservices/2003/engine");
            oMgr.AddNamespace("ddl400", "http://schemas.microsoft.com/analysisservices/2012/engine/400");
            System.IO.StringReader sreader = new System.IO.StringReader(xmla);
            using (XmlReader reader = XmlReader.Create(sreader, new XmlReaderSettings() { XmlResolver = null }))
            {
                xdoc.Load(reader);
            }

            try
            {
                ServerLocation = xdoc.SelectSingleNode("//ddl400:ServerLocation", oMgr).InnerText ?? "";
            }
            catch
            {
                ServerLocation = "";
            }
            try
            {
                ServerEdition = xdoc.SelectSingleNode("//d:Edition", oMgr).InnerText ?? "";
            }
            catch
            {
                ServerEdition = "";
            }
        }

        public ADOTabularConnection Clone(bool sameSession)
        {
            return CloneInternal(this.ConnectionStringWithInitialCatalog, sameSession);
        }

        public ADOTabularConnection Clone()
        {
            return CloneInternal(this.ConnectionStringWithInitialCatalog, false, false);
        }

        /// <summary>
        /// Checks if the connection string contains any of the RLS testing parameters
        /// </summary>
        /// <returns>bool</returns>
        public static bool HasRlsParameters(string connectionString)
        {
            var builder = new OleDbConnectionStringBuilder(connectionString);
            foreach (var param in rlsParameters)
            {
                if (builder.ContainsKey(param)) return true;
            }
            return false;
        }

        private static string[] rlsParameters = { "Roles", "EffectiveUserName", "Authentication Scheme", "Ext Auth Info" };
        public ADOTabularConnection CloneWithoutRLS()
        {
            var builder = new OleDbConnectionStringBuilder(ConnectionStringWithInitialCatalog);
            foreach (var param in rlsParameters)
            {
                builder.Remove(param);
            }
            var newConnStr = builder.ToString();
            return CloneInternal(newConnStr, false, false);
        }

        private ADOTabularConnection CloneInternal(string connectionString, bool sameSession)
        {
            return CloneInternal(connectionString, sameSession, true);
        }
        private ADOTabularConnection CloneInternal(string connectionString, bool sameSession, bool copyDatabaseReference)
        {
            if (this.ServerType == ServerType.Offline) return this;

            var connStrBuilder = new System.Data.OleDb.OleDbConnectionStringBuilder(connectionString);
            if (sameSession) connStrBuilder["SessionId"] = _adomdConn?.SessionID;
            var newConnStr = connStrBuilder.ToString();
            var cnn = new ADOTabularConnection(newConnStr, this.Type)
            {
                // copy keywords, functiongroups, DMV's
                _functionGroups = this._functionGroups,
                _keywords = this._keywords,
                _serverMode = this._serverMode,
                _dmvCollection = this._dmvCollection,
                ServerType = this.ServerType
            };
            if (!this.AccessToken.Equals(default(
#if NET8_0_OR_GREATER
                Microsoft.AnalysisServices.AccessToken
#else
                Microsoft.AnalysisServices.AdomdClient.AccessToken
#endif
                )))
            {
                // Wire up the renewal callback first so the clone can renew on demand, then copy the
                // token. The AccessToken setter renews it if it has expired - assigning an expired
                // token throws an ArgumentException ("The token has expired.") in the AdomdClient.
                cnn.OnAccessTokenExpired = OnAccessTokenExpired;
                cnn.AccessToken = this.AccessToken;
            }
            if (copyDatabaseReference)
            {
                cnn._db = this._db;
                cnn._adoTabDatabaseColl = this._adoTabDatabaseColl;
            }
            return cnn;
        }


    }

}
