﻿using DaxStudio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaxStudio.Core.Events
{
    public class ServerTimingsEvent : IServerTimes
    {
        public ServerTimingsEvent(IServerTimes timings)
        {
            Source = timings;
            FormulaEngineDuration = timings.FormulaEngineDuration;
            StorageEngineCpu = timings.StorageEngineCpu;
            StorageEngineCpuFactor = timings.StorageEngineCpuFactor;
            StorageEngineDuration = timings.StorageEngineDuration;
            StorageEngineQueryCount = timings.StorageEngineQueryCount;
            TotalDirectQueryDuration = timings.TotalDirectQueryDuration;
            TotalCpuDuration = timings.TotalCpuDuration;
            TotalCpuFactor = timings.TotalCpuFactor;
            TotalDuration = timings.TotalDuration;
            VertipaqCacheMatches = timings.VertipaqCacheMatches;
        }

        public IServerTimes Source { get; }
        public long FormulaEngineDuration { get; }
        public long StorageEngineCpu { get; }
        public double StorageEngineCpuFactor { get; }
        public long StorageEngineDuration { get; }
        public long StorageEngineQueryCount { get; }
        public long TotalDirectQueryDuration { get; }
        public long TotalCpuDuration { get; }
        public double TotalCpuFactor { get; }
        public long TotalDuration {get;}

        public int VertipaqCacheMatches { get; }

    }
}
