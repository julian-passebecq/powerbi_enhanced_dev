// Copyright (c) Microsoft Corporation.// Licensed under the MIT license.

/**
 * @hidden
 */
export class Config {
  public static readonly version: string = '3.0.0';
}
